Estrarre:
- Tracking.bat
- Tracking.jar
- Tracking.properties
- haarcascade_frontalface_alt.xml
- libcv64
- libser64
nella directory creata per l'applicazione.
Estrarre TrackPID e caricarlo su Arduino
Eventualmente modificare Tracking.properties in particolare nella voce 
   Port=...  (togliere il commento)
in base alla porta su cui � collegato Arduino.

A questo punto potete lanciare Tracking.bat

Volendo potete cambiare l'oggetto da tracciare scaricando un nuovo modello xml
da questo sito : file haarcascades.zip

Potete cambiare modello tramite Tracking.properties o direttamente come 
parametro di lancio.

Per avere l'help fare: Tracking.bat ?  

Per maggiori informazione sui parametri guardare lo sketch TracPID o il file 
sorgente Java: TrackArduPID.java

NB. La libreria seriale SerialLib.jar � stata completata con una classe per
una gestione semplificata della seriale simile alla gestione su Arduino. In ogni
caso contiene la documentazione e il sorgente.  