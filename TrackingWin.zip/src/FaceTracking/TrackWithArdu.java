package FaceTracking;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import Serial.SerialArduLike;

public class TrackWithArdu {
	
	String Port="COM4";
	int Bauds=9600;
	SerialArduLike Serial;	
	boolean prpar=false;	
	boolean deb=true;	
	PrintStream Hpr=System.out;	
	String filehaar = "haarcascade_frontalface_alt.xml";
	String fileprop="Tracking.properties";
	Properties param=new Properties();
	TrackArduPID T;
	
	String libcv="./libcv64/opencv_java320.dll";
	String libser="./libser64/rxtxSerial.dll";
	
	public static void main(String[] args) {
	    TrackWithArdu Main=new TrackWithArdu();
	    Main.loadProperties();
	    try {
			Main.libcv=new File(Main.libcv).getCanonicalPath();
		    Main.libser=new File(Main.libser).getCanonicalPath();
		} catch (IOException e) {Main.Hpr.println(e.getMessage());}
	    System.load(Main.libcv);
	    System.load(Main.libser);
        Main.T=new TrackArduPID();
	    Main.init();
        Main.menu(args);
	    if (Main.prpar) Main.printParam();
        Main.T.init();
        Main.T.cycle();
	}
	
	void loadProperties()
	{
		try {param.load(new FileInputStream(fileprop));} 
		catch (FileNotFoundException e) 
		{Hpr.println("No properties file:"+fileprop+". Default values are used.");return;}
		catch (IOException e) {e.printStackTrace();System.exit(-1);}
		libcv=param.getProperty("libcv", libcv);
		libser=param.getProperty("libser", libser);
	}
	
	void init()
	{
		Port=param.getProperty("Port",Port);
		String b=param.getProperty("Bauds");if (b!=null) Bauds=Integer.parseInt(b);
		filehaar=param.getProperty("Filehaar",filehaar);
		String sps=param.getProperty("SetPosition"); if (sps!=null) T.sps=sps; 
		String set=param.getProperty("SetCoefficients"); if (set!=null) T.set=set; 
		String stp=param.getProperty("SetPeriod"); if (stp!=null) T.stp=stp; 
		String sbf=param.getProperty("SetFilters"); if (sbf!=null) T.sbf=sbf;
		String slm=param.getProperty("SetLimits"); if (slm!=null) T.slm=slm;
		String db=param.getProperty("SetDebug");
		 if (db!=null)if (db.equalsIgnoreCase("ON")) T.deb=true; else T.deb=false;
	}
	
	void menu(String[] args)
	 {
	  int i;
	  for (i=0;i<args.length;i++)
	  try
	  {
	   if (args[0].substring(0,1).equalsIgnoreCase("?")) help();
	   if (args[0].substring(0,2).equalsIgnoreCase("/?")) help();
	   if (args[0].substring(0,4).equalsIgnoreCase("help")) help();
	   if (args[0].substring(0,5).equalsIgnoreCase("/help")) help();
	   if (args[0].substring(0,5).equalsIgnoreCase("debug")) T.deb=true;
	   if (args[0].substring(0,9).equalsIgnoreCase("showparam")) prpar=true;
	   if (args[i].substring(0,11).equalsIgnoreCase("serialport=")) Port=args[i].substring(11);
	   if (args[i].substring(0,6).equalsIgnoreCase("bauds=")) Bauds=Integer.parseInt(args[i].substring(6));
	   if (args[i].substring(0,9).equalsIgnoreCase("filehaar=")) filehaar=args[i].substring(9);
	  }
	  catch (Exception e) {}
	  
		Serial=new SerialArduLike();
		boolean ok=Serial.begin(Port, Bauds);
		if (!ok) {Hpr.print("No serial port "+Port+" Exit!");System.exit(-1);}
		Serial.flush();	
		T.Serial=Serial;
		T.face_cascade_name=filehaar;
		
		Hpr.println("Started Tracking ");
		Hpr.println("  - serial "+Port+"  bauds "+Bauds);
		Hpr.println("  - trained file: "+filehaar);
		Hpr.println("For help use ? as argument");		
	 }

	void help()
	{
		Hpr.println("*** Tracking with OpenCV e PanTilt con Arduino ***");
		Hpr.println("Default file haar-cascade (trained file): haarcascade_frontalface_alt.xml");
		Hpr.println("To set serial port or change file haar-cascade use this parameters:");
		Hpr.println("   serialport=...  bauds=...  filehaar=...  (don't care about order)");
		Hpr.println("For debug use parameter: debug");
		Hpr.println("For all parameters printing: showparam");
		Hpr.println("Properties file: "+fileprop);
        System.exit(0);
	}
				
    void printParam()
    {
    	Hpr.println("******");
    	Hpr.println("Debug: "+T.deb);
		Hpr.print("SetPosition: "+T.sps);  
		Hpr.print("SetCoefficients: "+T.set); 
		Hpr.print("SetPeriod: "+T.stp); 
		Hpr.print("SetFilters: "+T.sbf); 
		Hpr.println("******");
		Hpr.println("File properties: "+fileprop);
		Hpr.println("Native OpenCV lib: "+libcv);
		Hpr.println("Native Serial lib: "+libser);
		System.exit(0);
    }
    
	public void delay(long millis)
	{
		try {Thread.sleep(millis);}
		catch (InterruptedException e) {e.printStackTrace();}
	}	    
	
}
