#!/bin/bash
echo "Please note that : "
echo "         build-essential"
echo "         cmake"
echo "         git"
echo "         pkg-config"
echo "         ant"
echo "are required just for compilation"
echo "***"
echo "Verifing installed packages:" 
./deb_package_check \
build-essential \
cmake \
git \
pkg-config \
ant \
libgtk2.0-dev \
libavcodec-dev \
libavformat-dev \
libswscale-dev \
python-dev \
python-numpy \
libtbb2 \
libtbb-dev \
libjpeg-dev \
libpng12-dev \
libtiff5-dev \
libjasper-dev \
libdc1394-22-dev