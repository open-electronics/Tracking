package FaceTracking;
import java.awt.event.WindowAdapter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Locale;
import java.util.Random;

import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import Serial.SerialArduLike;

import com.atul.JavaOpenCV.Imshow;


public class TrackArduPID extends WindowAdapter{

	PrintStream Hpr=System.out;
	SerialArduLike Serial;	
	boolean deb=false;
	boolean dbdetect=false;
	
	String face_cascade_name = "haarcascade_frontalface_alt.xml"; //file addestrato
	CascadeClassifier face;  // Classificatore (rilevatore) di viso umano
	MatOfRect R;             // Matrice dei rettangoli che identificano gli oggetti
	Mat F;                   // Frame (singolo fotogramma dalla webcam) 
	VideoCapture V;	         // Collegamento con webcam (da cui leggere i frame)
	Imshow wv;               // Finestra semplificata per visualizzare il frame
	
	Rect rect;
	ShowFrame sf;	

	int dimx=320;
	int dimy=240;
	
	Random Rnd=new Random();
	
	Center center=new Center(0.5f,0.5f);

	int zoom=0;
	float fzoom=0;
	
	int timeout=500;
	
	public TrackArduPID(){}
	
	public TrackArduPID(SerialArduLike ser,boolean debug,String haar)
	{
		Serial=ser;
		deb=debug;
		if (haar!=null) if(haar.length()>2) face_cascade_name=haar; 
	}

    String sps="sps 90 88\n";
    String set="set 0.1 0.01 1.0 100 15\n";
    String stp="stp 50\n";
    String sbf="sbf 0.9 0.1\n";
    String slm;
    
	public void init()
	{
		sendToArdu("srs\n");           // reset accumulatori e Arduino flush
		Serial.flush();
		if (slm!=null) sendToArdu(slm);
		// Comandi di inizializzazione verso Arduino
		sendToArdu(sps);               // posiziona servo a met�
		sendToArdu(set);               // kp,ki,kd,kgx,kgy
		sendToArdu(stp);               // periodo 50 millisecondi
		sendToArdu(sbf);               // filtro di ingresso e filtro derivativo
		if (deb) sendToArdu("sdb\n");  // set Arduino PID debug
		
        face=new CascadeClassifier(face_cascade_name); // carica il file addestrato
	    if (face==null){end("No files!");}

	    // predispone il vettore che conterr� i rettangoli che circoscrivono gli oggetti identificati
	    R=new MatOfRect();                   
        
	    F=new Mat(dimy,dimx,3);              // buffer del singolo frame della telecamera
		V=new VideoCapture();                // periferica di acquisizione (webcam)
//		if (!V.open(0)) {end("No camera!");} // Apre la webcam (la prima : indice 0)
		if (!V.open(0)) {end("No PIcamera!");} // Apre la webcam (la prima : indice 0)
		V.set(Videoio.CAP_PROP_FRAME_WIDTH, (double)dimx);
		V.set(Videoio.CAP_PROP_FRAME_HEIGHT, (double)dimy);		
		V.set(Videoio.CAP_PROP_FPS, 60);
//		V.set(Videoio.CAP_MODE_RGB, 1);
		wv=new Imshow("Camera");		     // Apre la finestra dove saranno mostrati i frame
		wv.Window.addWindowListener(this);	 // gestisce la chiusura (windowclosed)
        
		sf=new ShowFrame(F,rect,wv);
		sf.start();
		delay(500);
		Hpr.println("Cores: "+Runtime.getRuntime().availableProcessors());
		
	}
	
	long ta,tb,tt;
	
	public void cycle()
	{
		
		while (readframe(F))     // Legge i singoli frame
		{
            if (detect(face)) {track();}  // se rileva il viso lo traccia
            else explore();               // altrimenti prova a cercarlo
		}
		sf.frame=false;
		V.release();
	}
	
	synchronized boolean readframe(Mat F)
	{
//		tb=System.currentTimeMillis();
		sf.frame=false;
		boolean f=V.read(F);
		sf.frame=true;
//		if (f) {Hpr.println("Frame time: "+(System.currentTimeMillis()-tb));}
		return f;
	}
	
    int ct=0;
	
	boolean detect(CascadeClassifier cl)
	{
	   ct++;
	   ta=System.currentTimeMillis();	
	   sf.r=null;
	   cl.detectMultiScale(F, R);   //rileva uno o pi�  visi fornendo un rettangolo che lo circoscrive
	   Rect r[]=R.toArray();        //trasforma la matrice di rettangoli in array per pi� semplice gestione 
	   if (r.length>0)              //considera il rettangolo che circoscrive il primo viso rilevato 
	   {
		 sf.r=r[0];  
	     int ix=r[0].x+(r[0].width)/2; //calcola il centro del rettangolo come float (0-:-1)
		 int iy=r[0].y+(r[0].height)/2;
		 center.set((float)ix/dimx, (float)iy/dimy);
		 tb=System.currentTimeMillis();
         if (deb){tt=tt+tb-ta;if (ct>=10) {Hpr.println("T.Detecting: "+(tt/10));tt=0;ct=0;}}
		 return true;
	   }	
	   else {return false;}		
	}
	
	
	void track()
	{
		if (dbdetect) Hpr.printf(Locale.ENGLISH,"> %4.3f %4.3f | ", center.getx(),center.gety());
		sendPosition();
		flost=false;clost=0;
	}
	
	int clost=0;
	int maxlost=15;
	boolean flost=false;
	
	void explore()
	{
		if (!flost)
		{
		  clost++;    //attende che passino maxlost cicli prima di affermare che la traccia � persa
		  if (clost<maxlost) {flost=false;return;} 
		  if (deb) Hpr.println("Lost trace..."); //la traccia � persa!
		  sendToArdu("srs\n");                   //reset accumulatori 
		  int scx=(int)(center.dx*100);          //prende in considerazione 
		  int scy=(int)(center.dy*100);          //gli ultimi spostamenti
		  ////ma se nulli usa valori random
		  if (scx==0) {scx=Rnd.nextInt(4)+1;if (Rnd.nextBoolean()) scx=-scx;}
		  if (scy==0) {scy=Rnd.nextInt(2)+1;if (Rnd.nextBoolean()) scy=-scy;}
		  sendToArdu("scn "+scx+" "+scy+"\n"); //inizializza i passi di scanning
		  flost=true;
		}
		else                   //se la traccia � stata gi� persa applica lo spostamento 
		{sendToArdu("scn\n");} //con i passi definiti (ma rimbalza automaticamente agli estremi)
	}

	void sendPosition()
	{
		Serial.print("%4.3f %4.3f\n", center.getx(),center.gety());
		readSerial();
	}
	
	void sendToArdu(String rec)
	{
		Serial.print(rec);
		readSerial();
	}
	
	void readSerial()
	{
		String rec;
		for (int i=0;i<timeout;i++) {if (!Serial.available()) delay(1);else break;}
		while (Serial.available())
		{
			rec=Serial.read();
			if (deb){Hpr.println("Ar: "+rec);printlnFile("Ar: "+rec);}
		}
	}
	
/*****************************************/	
	
	
	class Center
	{
		float x;
		float y;
		float dx,dy;
		float oldx,oldy;
		Center(float x,float y){this.x=x;this.y=y;oldx=x;oldy=y;}
		void set(float x,float y)
		{oldx=x;oldy=y;this.x=x;this.y=y;dx=dx+0.1f*(x-oldx-dx);dy=dy+0.1f*(y-oldy-dy);}
		float getx(){return x;}
		float gety(){return y;}
		float getdx(){return dx;}
		float getdy(){return dy;}
	}
	
	
/****************************************************************/	
	public void windowClosing()
	{V.release();end("End!");}
	
	public void end(String e)
	{
		if (pf!=null) pf.close();
	    Hpr.println(e);Hpr.flush();
	    Serial.print("sps %d %d\n",90,90);Serial.flush();Serial.end();
	    wv.Window.dispose();
	    System.exit(0);
	 }

	public void delay(long millis)
	{
		try {Thread.sleep(millis);}
		catch (InterruptedException e) {e.printStackTrace();}
	}	

    PrintStream pf=null;	
    public void printlnFile(String rec )
    {
    	if (pf==null)
			try {
				pf=new PrintStream (new FileOutputStream("./Debug/Debug.dat"));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
    	
    	pf.println(rec);
    	pf.flush();
    }
	
}
