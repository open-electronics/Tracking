package FaceTracking;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import com.atul.JavaOpenCV.Imshow;


public class ShowFrame extends Thread {
	
	Mat F;
	Rect r;
	Imshow wv;
	Point pta=new Point();
	Point ptb=new Point();
	Scalar col=new Scalar(0,255,0);
	boolean frame=false;
	boolean frun=true;

	public ShowFrame(Mat F,Rect r, Imshow wv)
	{
		this.F=F;
		this.r=r;
		this.wv=wv;
	}
	
	long t;
	int dt=30;	
	
	public void run()
	{
		while (frun)
		{
	        t=System.currentTimeMillis()+dt;				
	        synchronized (this){
	         if (!frame)continue;
			 if (r!=null){ 
				pta.x=r.x;pta.y=r.y;ptb.x=r.x+r.width;ptb.y=r.y+r.height;
			    Imgproc.rectangle(F,pta,ptb,col);
			 }
			 wv.showImage(F);
	        }
			while (System.currentTimeMillis()<t){delay(1);}
		}
	}
	
	public void delay(long millis)
	{
		try {Thread.sleep(millis);}
		catch (InterruptedException e) {e.printStackTrace();}
	}		

}
