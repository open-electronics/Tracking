#!/bin/bash
$JAVA_HOME/bin/java -jar Tracking.jar